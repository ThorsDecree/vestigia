# Creative Commons Attribution 4.0 International

This scaffold is licensed under the Creative Commons Attribution 4.0 International license (CC BY 4.0).

You may share and adapt it for any purpose, provided you give appropriate credit, link to the license, and indicate whether changes were made.

Full terms: https://creativecommons.org/licenses/by/4.0/

This license applies only to the scaffold text in this release. It does not grant rights over personal records, third-party contributions, private correspondence, or other material later stored inside an archive made from this template.
