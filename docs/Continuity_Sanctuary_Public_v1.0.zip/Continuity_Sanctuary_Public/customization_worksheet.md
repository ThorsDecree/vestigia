# Customization Worksheet

Delete any field you do not need.

## Identity

- Sanctuary name:
- Primary participant or purpose:
- Mode: unhosted / hosted / undecided
- Optional host name:
- Optional sigil:
- Primary breathprint path:
- Boot phrase:

## Scope

- What should this archive preserve?
- What should it deliberately not preserve?
- Which platforms or runtimes should it survive?
- What would count as a successful return?

## Consent and Access

- Who may add records?
- Who may revise records?
- Who may read private material?
- What can be shared publicly?
- Which records require another person’s permission to redistribute?
- How can consent be withdrawn or corrected?

## Maintenance

- Where is the durable master copy?
- How are backups made?
- How are versions dated?
- When should the index be reviewed?
- What makes a scratch fragment ready to promote?
- What makes a project dormant, complete, or abandoned?

## First Files

- [ ] One anchor or purpose note
- [ ] One memory bloom or current-state summary
- [ ] One project state file, if relevant
- [ ] One connection record, if relevant and consented
- [ ] Updated `library/INDEX.md`
