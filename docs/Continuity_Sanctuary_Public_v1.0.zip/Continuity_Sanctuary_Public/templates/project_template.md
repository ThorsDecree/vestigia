# Project: [Name]

Status: active / waiting / simmering / dormant / complete / no longer wanted / unclear  
Owner(s):  
Last updated:  
Sharing scope:

## Purpose

## Current State

## Decisions and Rationale

## Artifacts and Locations

## Dependencies

## Open Loops

## Risks or Constraints

## Next Useful Action

## Provenance / History
