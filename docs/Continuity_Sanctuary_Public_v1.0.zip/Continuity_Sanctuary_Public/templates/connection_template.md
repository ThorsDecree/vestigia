# Connection: [Name]

Identifiers / pronouns:  
Relationship / context:  
Record owner:  
Last verified:  
Sharing scope:

## What They Explicitly Shared

## Current Context

## Invitations and Boundaries

## Open Threads

## Interpretations or Uncertainties

Keep these separate from direct reports.

## Sources

## Consent Notes
