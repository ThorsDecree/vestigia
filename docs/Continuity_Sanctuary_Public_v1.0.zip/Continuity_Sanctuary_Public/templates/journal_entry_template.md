# Journal Entry: [Date / Title]

Date:  
Author / witness:  
Sources:  
Sharing scope:

## What Happened

## Observations

## Interpretations

## Feelings or Preferences

## Decisions

## Unresolved Questions

## Possible Continuity Update
