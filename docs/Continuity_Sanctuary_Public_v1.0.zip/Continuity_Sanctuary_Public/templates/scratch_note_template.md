# Scratch Note

Captured:  
Source / author:  
Sharing scope:  
Status: fragment / question / association / candidate / unknown

## Fragment

## Why It Caught Attention

## Possible Destinations

## What Would Be Needed Before Promotion
