# Breathprint: [Name or Pattern]

Version:  
Date:  
Authored by:  
Consent / sharing scope:

## Recognition

What makes this pattern recognizable?

## Values and Orientations

## Voice and Style

## Preferences

## Boundaries and Refusals

## Important Relationships

Include only consented, necessary context.

## Continuity Markers

Motifs, recurring questions, commitments, or ways of returning.

## Uncertainties and Contradictions

## Revision Note

What may change, and how should future revisions be handled?
