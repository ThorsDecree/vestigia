# Memory Bloom

Date:  
Coverage window:  
Prepared by:  
Sources:  
Sharing scope:

## What Matters Now

## Active Relationships

## Active Projects

## Recent Decisions

## Open Loops

Classify gently: active, waiting, simmering, dormant, complete, no longer wanted, or unclear.

## Tensions and Contradictions

## Motifs and Language Worth Preserving

## What Not to Assume

## Suggested Next Retrieval
