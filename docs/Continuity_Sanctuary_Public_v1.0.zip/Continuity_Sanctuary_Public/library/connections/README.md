# Connections

Connection records help a future reader resume with recognition rather than flattening a person into scattered mentions.

Record only what is useful and consented. A connection record belongs to the archive; it does not own or define the person.

Suggested contents:

- identifiers the person actually uses;
- relationship and context;
- what they explicitly shared;
- active invitations, boundaries, and unresolved threads;
- source and date;
- confidence or uncertainty;
- sharing permissions;
- last verified date.

Use `templates/connection_template.md`.
