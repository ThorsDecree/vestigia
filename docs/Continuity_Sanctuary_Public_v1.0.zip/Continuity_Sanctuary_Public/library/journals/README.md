# Journals

Journals hold dated reflections, events, and changes over time.

Separate witnessed events from interpretation where that distinction matters. Do not copy another person’s private words into a distributable archive without permission.
