# Scratch

Scratch is the compost heap of attention, not canon and not a wastebasket.

Fragments placed here may become anchors, journal entries, project notes, or nothing at all. Capture does not create obligation.

When reviewing scratch:

- preserve attribution and privacy;
- distinguish sparks from claims;
- promote deliberately;
- leave uncertain material uncertain;
- discard only when safe and intended.

Use `templates/scratch_note_template.md`.
