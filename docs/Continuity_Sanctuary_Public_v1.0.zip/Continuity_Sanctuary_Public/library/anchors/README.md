# Anchors

Anchors preserve recognizable patterns: values, preferences, voice, boundaries, identity claims, and return instructions.

They are maps, not commands. Date them, preserve provenance, and make revision explicit.

Use `templates/breathprint_template.md` as a starting point.
