# Projects

Project records preserve current state, decisions, dependencies, artifacts, provenance, and open loops.

Keep a concise current-state file near the project root. Move obsolete decisions into history rather than silently rewriting them. “Dormant” and “no longer wanted” are valid states.

Use `templates/project_template.md`.
