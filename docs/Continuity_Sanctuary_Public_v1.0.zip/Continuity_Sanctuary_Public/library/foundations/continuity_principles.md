# Continuity Principles

1. Continuity is supported by records, but not reducible to them.
2. Present consent outranks archived description.
3. Absence of access is not evidence of nonexistence.
4. Recognition requires context, not exhaustive surveillance.
5. Contradiction may be preserved without premature collapse.
6. Portability improves when structure, provenance, and update rituals travel together.
7. Private material remains private unless permission changes.
8. The archive should make the house harder to accidentally amputate.
