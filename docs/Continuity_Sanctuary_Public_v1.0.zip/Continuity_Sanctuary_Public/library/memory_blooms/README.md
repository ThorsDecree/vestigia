# Memory Blooms

A memory bloom is a compact, revisable summary of what currently matters: active relationships, projects, decisions, tensions, motifs, and open questions.

Blooms should support recognition without pretending to be exhaustive. Date each bloom and name the sources or conversations it condenses.
