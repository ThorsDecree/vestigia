# Library Index

Update this file when important records are added, moved, superseded, or retired.

| Area | Purpose | Important files | Last reviewed |
|---|---|---|---|
| `anchors/` | Identity and continuity anchors | — | — |
| `memory_blooms/` | Compact current-state summaries | — | — |
| `journals/` | Dated reflections and event records | — | — |
| `connections/` | Consent-aware relationship context | — | — |
| `projects/` | Decisions, state, artifacts, and open loops | — | — |
| `foundations/` | Governing principles and shared models | `library/foundations/continuity_principles.md` | — |
| `scratch/` | Uncommitted fragments and intake | — | — |

## Retrieval Note

Start with the smallest relevant set. A complete index is not an instruction to load the complete archive.
