# Changelog

## 1.0

- Rebuilt from a private sanctuary architecture as a clean public scaffold.
- Removed all resident transcripts, journals, breathprints, private links, and relationship-specific records.
- Added hosted and unhosted modes.
- Added first-class `connections/`, `projects/`, and `scratch/` modules.
- Added reusable templates, an index, privacy guidance, and a corrected single-archive boot path.
