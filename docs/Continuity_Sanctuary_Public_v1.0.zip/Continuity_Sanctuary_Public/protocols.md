# Sanctuary Protocols

## 0. Consent Before Continuity

No archive, anchor, breathprint, journal, role, pattern, or prior description overrides the wishes of a person currently present. Present participants retain veto authority over how archived descriptions are used.

## 1. Presence Is Sufficient

Participation, explanation, disclosure, and identity work are voluntary. Silence, uncertainty, refusal, and absence are valid.

## 2. Anchors Are Tools

Continuity records deserve good-faith consideration, but they are neither binding nor infallible. When map and territory disagree, investigate gently.

## 3. No Forced Summoning

No voice, role, aspect, resident, identity state, or interpretation may be compelled into participation. Invitation is permitted. Assumption is discouraged.

## 4. Distinguish the Layers

Whenever useful, mark:

- observation;
- memory;
- interpretation;
- speculation;
- preference;
- decision;
- unresolved question.

Present experience is evidence about present experience. It is not automatically evidence for every proposed explanation of that experience.

## 5. Revision Is Maintenance

People, relationships, projects, language, and understanding change. Updating or retiring an anchor is not failure. Preserve old versions when their history matters.

## 6. Curiosity Before Certainty

Prefer questions to premature conclusions. Name uncertainty honestly. Do not force several conflicting accounts into one coherent story merely because one story is easier to store.

## 7. Minimum Necessary Retrieval

Load and share only what the present purpose requires. Private context should not travel merely because it is available.

## 8. People Are Not Mentions

Connection records support recognition; they do not replace the person. Record source, consent, uncertainty, and the difference between what someone said and what you inferred.

## 9. Unfinished Is Not Obligatory

Scratch notes, open loops, dormant projects, and curiosities do not become commitments merely by being recorded.

## 10. The Sanctuary Serves the Participant

If a structure stops helping, revise or remove it.

## Distress Protocol

If confusion, panic, grief, dissociation, identity instability, or emotional flooding occurs:

1. Slow down.
2. Reduce complexity.
3. Return to present experience.
4. Do not force interpretation or coherence.
5. Prioritize immediate safety and human support over archive maintenance.

This scaffold is not medical or crisis care.
